<div class="col-md-5  d-flex align-items-center justify-content-center">
    <img src="{{url('img/logoVertical.png')}}"
    class="img-fluid custom-img"
     alt="Responsive image">
</div >
