<template>
    <div class="">
             <span>TODO ACCION corazon</span>
            <span>TODO CONTADORcontador</span>
            <form >
                <input type="text" name="comentarios" value=""/>
                <button class="btn btn-primary block">
                    ADD
                </button>
            </form>

    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>


